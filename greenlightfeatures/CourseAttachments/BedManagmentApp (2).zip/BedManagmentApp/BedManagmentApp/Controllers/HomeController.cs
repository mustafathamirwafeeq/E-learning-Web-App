﻿using BedManagmentApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BedManagmentApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(string WardName)
        {
            if (string.IsNullOrEmpty(WardName)) WardName = "ALL";
            HospitalRoomsViewModel HospitalRoomsViewModel = new HospitalRoomsViewModel(WardName);

            return View(HospitalRoomsViewModel);
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}