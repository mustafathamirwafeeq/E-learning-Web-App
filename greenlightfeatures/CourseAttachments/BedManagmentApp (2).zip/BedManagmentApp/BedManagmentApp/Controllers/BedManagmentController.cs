﻿using BedManagmentApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BedManagmentApp.Controllers
{
    public class BedManagmentController : Controller
    {
        //
        // GET: /BedManagment/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DisplayRoomsDetails(string RoomID)
        {
            HospitalRoomDetailViewModel _HospitalRoomDetailViewModel = new HospitalRoomDetailViewModel(RoomID);
 
            return View(_HospitalRoomDetailViewModel);
        }

        public ActionResult DisplayPatientInfo(string PatientID)
        {  
            return View();
        }

    }
}
