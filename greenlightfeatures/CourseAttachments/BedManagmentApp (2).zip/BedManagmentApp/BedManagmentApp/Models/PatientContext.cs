﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BedManagmentApp.Migrations;


namespace BedManagmentApp.Models
{
    public class PatientContext : DbContext
    {
        
        public PatientContext()
            : base("DefaultConnection")
        {
        }

        public DbSet<Patient> Patients { get; set; }

         //Automatic Update
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<PatientContext, ConfigurationForPatients>());
        }

        // Methods...

        public IQueryable<Patient> GetAll()
        {
            IQueryable<Patient> query = this.Patients;
            return query;
        }

        public Patient GetSingleByID(int _PatientID)
        {
            var query = this.GetAll().FirstOrDefault(x => x.PatientID == _PatientID);
            return query;
        }

        public Patient GetSingleByName(string _Name)
        {
            var query = this.GetAll().FirstOrDefault(x => x.PatientName.ToLower().Contains(_Name));
            return query;
        }



        public IQueryable<Patient> GetAllDriversByAdmissionDate(DateTime _AdmissionDate)
        {
            IQueryable<Patient> query = this.Patients.Where(x => x.AdmissionDate >= _AdmissionDate);

            return query;
        }

        public bool Save(Patient _Patient)
        {
            bool _SuccessFlg = true;

            try
            {
                if (_Patient.ID == 0)
                {
                    this.Patients.Add(_Patient);
                    this.Entry<Patient>(_Patient).State = System.Data.Entity.EntityState.Added;
                    this.SaveChanges();
                }
                else
                {
                    this.Entry<Patient>(_Patient).State = System.Data.Entity.EntityState.Modified;
                    this.SaveChanges();
                }

            }
            catch
            {
                _SuccessFlg = false;
            }

            return _SuccessFlg;
        }

    }

}
