﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BedManagmentApp.Models
{
    public class Patient
    {
        [Key]
        public int ID { get; set; }
        public int PatientID { get; set; }
        public string PatientName { get; set; }
        public string PatientLastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int StayDays { get; set; }
        public string Nationality { get; set; }
        public string Gender { get; set; }
        public DateTime AdmissionDate { get; set; }
        public string MobileNumber { get; set; }
        public string Diagnosis { get; set; }
        public string PatientImg { get; set; }
        

        public Patient () { }
        public string ToPatientString()
        {
            string PatientStr = string.Empty;
           PatientStr = PatientID.ToString() + "," + PatientLastName + "," + PatientName + "," +
                       Nationality + "," + Gender + "," + AdmissionDate + "," + Diagnosis;

           
            return PatientStr;
        }

        public void SetNewPatient()
        {
            this.PatientID = 0;
            this.AdmissionDate= DateTime.Today;
            this.DateOfBirth = DateTime.Today.AddYears(-25);
            this.Nationality = "Omani";
            this.Gender = "female";
            this.Diagnosis = "Iscs";
          
        }
    }
}
       
    
