﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BedManagmentApp.Migrations;



namespace BedManagmentApp.Models
{
    public class RoomContext : DbContext
    {
        public RoomContext()
            : base("DefaultConnection")
        {
        }

        public DbSet<Room> Rooms{ get; set; }

         //Automatic Update
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<RoomContext, ConfigurationForRooms>());
        }

        // Methods...

        public IQueryable<Room> GetAll()
        {
            IQueryable<Room> query = this.Rooms;
            return query;
        }

        public IQueryable<Room> GetAllRoomsByWardName(string _WardName)
        {
            IQueryable<Room> query = this.GetAll().Where(x => x.Ward == _WardName);
            return query;
        }

        public Room GetSingleByID(string _RoomID)
        {
            var query = this.GetAll().FirstOrDefault(x => x.RoomID == _RoomID);
            return query;
        }

        public Room GetSingleBedID(string _BedID)
        {
            var query = this.GetAll().FirstOrDefault(x => x.BedIds.Contains(_BedID));
            return query;
        }


        public bool Save(Room _Room)
        {
            bool _SuccessFlg = true;

            try
            {
                if (_Room.ID == 0)
                {
                    this.Rooms.Add(_Room);
                    this.Entry<Room>(_Room).State = System.Data.Entity.EntityState.Added;
                    this.SaveChanges();
                }
                else
                {
                    this.Entry<Room>(_Room).State = System.Data.Entity.EntityState.Modified;
                    this.SaveChanges();
                }

            }
            catch
            {
                _SuccessFlg = false;
            }

            return _SuccessFlg;
        }

    }

}