﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BedManagmentApp.Models
{
    public class HospitalRoomDetailViewModel
    {
        public Room Room { get; set; }    
        public bool IsFull { get; set; }       

        public List<Bed> RoomBeds = new List<Bed>();
        public List<Patient> RoomPatients = new List<Patient>();

        public HospitalRoomDetailViewModel(string _RoomID)
        {
            this.GetRoomInfo(_RoomID);         
        }

        public void GetRoomInfo(string _RoomID)
        {
            this.IsFull = false;

            using(RoomContext RoomContext = new RoomContext())
            {
                this.Room = RoomContext.GetSingleByID(_RoomID);
            }

            if(this.Room != null)
            {
                using (BedContext BedContext = new BedContext())
                {
                    string[] bedsStr = this.Room.BedIds.Split('+');

                    for(int i = 0; i < bedsStr.Length; i++)
                    {
                        string BedId = bedsStr[i];

                        Bed _Bed = BedContext.GetSingleByID(BedId);

                        if(_Bed != null)
                        {
                            this.RoomBeds.Add(_Bed);

                            using(PatientContext PatientContext = new PatientContext())
                            {
                                Patient _Patient = PatientContext.GetSingleByID(_Bed.PatientID);

                                if(_Patient != null)
                                {
                                    this.RoomPatients.Add(_Patient);
                                }
                            }
                        }
                       
                    }
                }

                // check if Room is Full
                if (this.Room.BedCount == this.RoomPatients.Count)
                {
                    this.IsFull = true;
                }
            }
        }

    }
}
    
