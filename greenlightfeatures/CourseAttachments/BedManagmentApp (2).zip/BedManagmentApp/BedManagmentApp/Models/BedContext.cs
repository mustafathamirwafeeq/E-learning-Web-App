﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using BedManagmentApp.Migrations;



namespace BedManagmentApp.Models
{
    public class BedContext : DbContext
    {
        public BedContext()
            : base("DefaultConnection")
        {
        }

        public DbSet<Bed> Beds{ get; set; }

         //Automatic Update
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<BedContext, ConfigurationForBeds>());
        }

        // Methods...

        public IQueryable<Bed> GetAll()
        {
            IQueryable<Bed> query = this.Beds;
            return query;
        }

        public Bed GetSingleByID(string _BedID)
        {
            var query = this.GetAll().FirstOrDefault(x => x.BedID == _BedID);
            return query;
        }

        public Bed GetSinglePatientName(int _PatientID)
        {
            var query = this.GetAll().FirstOrDefault(x => x.PatientID == _PatientID);
            return query;
        }


        public bool Save(Bed _Bed)
        {
            bool _SuccessFlg = true;

            try
            {
                if (_Bed.ID == 0)
                {
                    this.Beds.Add(_Bed);
                    this.Entry<Bed>(_Bed).State = System.Data.Entity.EntityState.Added;
                    this.SaveChanges();
                }
                else
                {
                    this.Entry<Bed>(_Bed).State = System.Data.Entity.EntityState.Modified;
                    this.SaveChanges();
                }

            }
            catch
            {
                _SuccessFlg = false;
            }

            return _SuccessFlg;
        }

    }

}