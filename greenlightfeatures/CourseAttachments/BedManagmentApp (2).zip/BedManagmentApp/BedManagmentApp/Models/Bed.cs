﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BedManagmentApp.Models
{
    public class Bed
    {
        [Key]
        public int ID { get; set; }
        public string BedID { get; set; }
        public string RoomID { get; set; }
        public int PatientID { get; set; }
        public string Ward { get; set; }

        public Bed() { }

    }

}
    
