﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BedManagmentApp.Models
{
    public class Room
    {
        [Key]
        public int ID { get; set; }
        public string RoomID { get; set; }
        public int BedCount { get; set; }
        public string BedIds { get; set; }
        public string Ward { get; set; }
        public bool IsPrivate { get; set; }

        // None DB variables

        public bool IsFull = false;
        public Room() { }

        public void SetRoomDetails()
        {

        }

    }

}
    
