﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BedManagmentApp.Models
{
    public class HospitalBedsViewModel
    {
        public string JasonBedInfo { get; set; }
        public string PatientBedInfo { get; set; }
        public string BedInfo { get; set; }

        public List<Room> AllRooms = new List<Room>();
       
        public HospitalBedsViewModel()
        {
            this.GetRoomInfo();
        }

        public void GetRoomInfo()
        {

            // Get all beds from the database
            using (RoomContext RoomContext = new RoomContext())
            {
                this.AllRooms = RoomContext.GetAll().ToList();
            }

        }

        public void MakeHospital()
        {
            Dictionary<string, int> HospialWards = new Dictionary<string, int>();

            HospialWards.Add("Emergency", 10);
            HospialWards.Add("Anaesthetics", 10);
            HospialWards.Add("Cardiology", 20);
            HospialWards.Add("Gastroenterology", 10);
            HospialWards.Add("Surgery", 20);
            HospialWards.Add("Gynaecology", 20);
            HospialWards.Add("Haematology", 10);
            HospialWards.Add("Neurology", 20);
            HospialWards.Add("Maternity", 16);
            HospialWards.Add("Oncology", 10);
            HospialWards.Add("Ophthalmology", 8);
            HospialWards.Add("Orthopaedics", 10);
            HospialWards.Add("Otolaryngology", 8);
            HospialWards.Add("Radiology", 2);
            HospialWards.Add("Urology ", 6);
            HospialWards.Add("Rheumatology", 8);
            HospialWards.Add("Microbiology", 10);
            HospialWards.Add("Critical Care", 20);

            int PatientId = 100;
            Random Age = new Random();
            Random StayDays = new Random();

            // Save Rooms in DB
            using (RoomContext RoomContext = new RoomContext())
            {
                using (PatientContext PatientContext = new PatientContext())
                {
                    using (BedContext BedContext = new BedContext())
                    {
                        foreach (KeyValuePair<string, int> ward in HospialWards)
                        {
                            for (int i = 0; i < ward.Value; i++)
                            {
                                Room _Room = null;
                                Bed _Bed = null;

                                if (i < 4)
                                {
                                    _Room = (new Room()
                                    {
                                        ID = 0,
                                        RoomID = ward.Key.Substring(0, 2) + "_" + i,
                                        BedCount = 1,
                                        Ward = ward.Key,
                                        IsPrivate = true
                                    });

                                    PatientId++;
                                    int days = StayDays.Next(1,10);
                                    Patient _Patient = (new Patient()
                                    {
                                        ID = 0,
                                        PatientID = PatientId,
                                        PatientName = "Eve" + PatientId,
                                        PatientLastName = "Salam",
                                        DateOfBirth = DateTime.Today.AddDays(Age.Next(10,40)),
                                        StayDays = days,
                                        Nationality = "Oman",
                                        Gender = "F",
                                        AdmissionDate = DateTime.Today.AddDays(days),
                                        MobileNumber = "",
                                        Diagnosis = ward.Key,
                                        PatientImg = "~/Content/images/Patient.png"

                                    });

                                    //PatientContext.Save(_Patient);

                                    _Bed = (new Bed()
                                    {
                                        ID = 0,
                                        BedID = _Room.RoomID + "_A",
                                        RoomID = _Room.RoomID,
                                        PatientID = _Patient.PatientID,
                                        Ward = ward.Key,

                                    });

                                    BedContext.Save(_Bed);

                                    _Room.BedIds += _Bed.BedID + "+";


                                }
                                else
                                {
                                    _Room = (new Room()
                                    {
                                        ID = 0,
                                        RoomID = ward.Key.Substring(0, 2) + "_" + i,
                                        BedCount = 2,
                                        Ward = ward.Key,
                                        IsPrivate = false
                                    });

                                    PatientId++;
                                    int days = StayDays.Next(1, 10);
                                    Patient _PatientA = (new Patient()
                                    {
                                        ID = 0,
                                        PatientID = PatientId,
                                        PatientName = "Eve" + PatientId,
                                        PatientLastName = "Salam",
                                        DateOfBirth = DateTime.Today.AddDays(Age.Next(10, 40)),
                                        StayDays = days,
                                        Nationality = "Oman",
                                        Gender = "F",
                                        AdmissionDate = DateTime.Today.AddDays(days),
                                        MobileNumber = "",
                                        Diagnosis = ward.Key,
                                        PatientImg = "~/Content/images/Patient.png"

                                    });

                                    //PatientContext.Save(_PatientA);

                                    _Bed = (new Bed()
                                    {
                                        ID = 0,
                                        BedID = _Room.RoomID + "_A",
                                        RoomID = _Room.RoomID,
                                        PatientID = _PatientA.PatientID,
                                        Ward = ward.Key,

                                    });

                                    BedContext.Save(_Bed);
                                    _Room.BedIds += _Bed.BedID + "+";

                                    PatientId++;
                                    days = StayDays.Next(1, 10);
                                    Patient _PatientB = (new Patient()
                                    {
                                        ID = 0,
                                        PatientID = PatientId,
                                        PatientName = "Eve" + PatientId,
                                        PatientLastName = "Salam",
                                        DateOfBirth = DateTime.Today.AddDays(Age.Next(10, 40)),
                                        StayDays = days,
                                        Nationality = "Oman",
                                        Gender = "F",
                                        AdmissionDate = DateTime.Today.AddDays(days),
                                        MobileNumber = "",
                                        Diagnosis = ward.Key,
                                        PatientImg = "~/Content/images/Patient.png"

                                    });

                                    //PatientContext.Save(_PatientB);

                                    _Bed = (new Bed()
                                    {
                                        ID = 0,
                                        BedID = _Room.RoomID + "_B",
                                        RoomID = _Room.RoomID,
                                        PatientID = _PatientB.PatientID,
                                        Ward = ward.Key,

                                    });

                                    BedContext.Save(_Bed);

                                  
                                    _Room.BedIds += _Bed.BedID;
                                }

                                //RoomContext.Save(_Room);

                            }
                        }
                    }
                }
            }

        }

    }
}
    
