
$(document).ready(function () {/* activate sidebar */
    
    /* activate scrollspy menu */
    var $body = $(document.body);
    var navHeight = $('.navbar').outerHeight(true) + 10;

    $body.scrollspy({
        target: '#leftCol',
        offset: navHeight
    });

    /* smooth scrolling sections */
    $('a[href*=#]:not([href=#])').click(function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top - 50
                }, 1000);
                return false;
            }
        }
    });

});

function scrollToElement(selector, time, verticalOffset) {
    time = typeof (time) != 'undefined' ? time : 1000;
    verticalOffset = typeof (verticalOffset) != 'undefined' ? verticalOffset : 0;
    element = $(selector);
    offset = element.offset();
    offsetTop = offset.top + verticalOffset;
    $('html, body').animate({
        scrollTop: offsetTop
    }, time);
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function ShowNotification()
{
    var url = "/Account/UserNotifications";
    $.ajax({
        url: url, async: true, success: function (result) {
            if (result.status == 0) {
                $("#notification-message").html(result.data);
                $('#NotificationBox').modal('show');
            }

        }, error: function () {
            alert("Sorry! system failed to perform action.");
        }
    });
}

function SaveTextSize(textSize) {
    var url = "/Account/SaveTextSize?textSize=" + textSize;
    $.ajax({
        url: url, async: true, success: function (result) {
            if (result.status == 0) {
               //
            }

        }, error: function () {
            alert("Sorry! system failed to perform action.");
        }
    });
}

function GetTextSize() {
    var url = "/Account/GetTextSize";
    $.ajax({
        url: url, async: true, success: function (result) {
            if (result.status == 0) {
                SetTextSize(result.data)
            }

        }, error: function () {
            alert("Sorry! system failed to perform action.");
        }
    });
}

function SaveBookmark(suraId, verseId) {
    var url = "/Account/SaveBookmark?suraId=" + suraId + "&verseId=" + verseId;
    $.ajax({
        url: url, async: true, success: function (result) {
            if (result.status == 0) {
                ShowSuccessMessage('Aya has been bookmarked successfully');
            }

        }, error: function () {
            alert("Sorry! system failed to perform action.");
        }
    });
}

function SetTextSize(textSize)
{
    $('.arabic').css('font-size', textSize);
    if (textSize == '28px') {
        $('.tamil').css('font-size','16px');
    }
    else {
        $('.tamil').css('font-size', (textSize.substring(0, 2) - 22) + 'px');
    }
}

function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
