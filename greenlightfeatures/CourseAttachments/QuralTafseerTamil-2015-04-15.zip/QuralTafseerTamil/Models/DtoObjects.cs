﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuralTafseerTamil.Models
{
    public partial class SearchQuranResultDto
    {

        private long _id;

        private long _para_id;

        private long _sura_id;

        private long _lang_id;

        private long _text_type_id;

        private int _verse_number;

        private string _text;

        private System.DateTime _create_time;

        private System.Nullable<System.DateTime> _update_time;

        public SearchQuranResultDto()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "BigInt NOT NULL")]
        public long id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this._id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_para_id", DbType = "BigInt NOT NULL")]
        public long para_id
        {
            get
            {
                return this._para_id;
            }
            set
            {
                if ((this._para_id != value))
                {
                    this._para_id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_sura_id", DbType = "BigInt NOT NULL")]
        public long sura_id
        {
            get
            {
                return this._sura_id;
            }
            set
            {
                if ((this._sura_id != value))
                {
                    this._sura_id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_lang_id", DbType = "BigInt NOT NULL")]
        public long lang_id
        {
            get
            {
                return this._lang_id;
            }
            set
            {
                if ((this._lang_id != value))
                {
                    this._lang_id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_text_type_id", DbType = "BigInt NOT NULL")]
        public long text_type_id
        {
            get
            {
                return this._text_type_id;
            }
            set
            {
                if ((this._text_type_id != value))
                {
                    this._text_type_id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_verse_number", DbType = "Int NOT NULL")]
        public int verse_number
        {
            get
            {
                return this._verse_number;
            }
            set
            {
                if ((this._verse_number != value))
                {
                    this._verse_number = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_text", DbType = "NVarChar(MAX) NOT NULL", CanBeNull = false)]
        public string text
        {
            get
            {
                return this._text;
            }
            set
            {
                if ((this._text != value))
                {
                    this._text = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_create_time", DbType = "DateTime NOT NULL")]
        public System.DateTime create_time
        {
            get
            {
                return this._create_time;
            }
            set
            {
                if ((this._create_time != value))
                {
                    this._create_time = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_update_time", DbType = "DateTime")]
        public System.Nullable<System.DateTime> update_time
        {
            get
            {
                return this._update_time;
            }
            set
            {
                if ((this._update_time != value))
                {
                    this._update_time = value;
                }
            }
        }
    }

    public class ContactDto
    {
        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        
        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public string Subject { get; set; }

        public string Message { get; set; }

    }

    public class SendToFriendDto
    {
        [Required]
        [Display(Name = "Your Name")]
        public string FromName { get; set; }

        [Required]
        [Display(Name = "Your Email")]
        [EmailAddress]
        public string FromEmail { get; set; }

        [Required]
        [Display(Name = "Friend Name")]
        public string ToName { get; set; }

        [Required]
        [Display(Name = "Friend Eamil")]
        [EmailAddress]
        public string ToEmail { get; set; }

    }
}