﻿using QuralTafseerTamil.Models;
using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Web;

namespace QuralTafseerTamil
{
    public class dbUtilities : IUtilities
    {
        public List<Language> GetLanguages(long lang_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            if (lang_id == 0)
                return db.Languages.ToList();
            else
            {
                return new List<Language> { db.Languages.SingleOrDefault(x => x.id == lang_id) };
            }
        }
        public List<Text_Type> GetTextTypes(long text_type_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            if (text_type_id == 0)
                return db.Text_Types.ToList();
            else
            {
                return new List<Text_Type> { db.Text_Types.SingleOrDefault(x => x.id == text_type_id) };
            }
        }
        public List<Sura> GetSuras(long sura_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            if (sura_id == 0)
                return db.Suras.ToList();
            else
            {
                return new List<Sura> { db.Suras.SingleOrDefault(x => x.id == sura_id) };
            }
        }
        public List<Sura_Detail> GetSuraDetails(long sura_id, long sura_detail_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            if (sura_id == 0 && sura_detail_id == 0)
                return db.Sura_Details.ToList();
            else if (sura_id == 0 && sura_detail_id != 0)
            {
                return new List<Sura_Detail> { db.Sura_Details.SingleOrDefault(x => x.id == sura_detail_id) };
            }
            else if (sura_id != 0 && sura_detail_id == 0)
            {
                return db.Sura_Details.Where(x => x.sura_id == sura_id).ToList();
            }
            else if (sura_id != 0 && sura_detail_id != 0)
            {
                return new List<Sura_Detail> { db.Sura_Details.SingleOrDefault(x => x.sura_id == sura_id && x.id == sura_detail_id) };
            }
            else
            {
                return new List<Sura_Detail>();
            }
        }
        public List<Para> GetParas(long para_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            if (para_id == 0)
                return db.Paras.ToList();
            else
            {
                return new List<Para> { db.Paras.SingleOrDefault(x => x.id == para_id) };
            }
        }
        public List<Para_Detail> GetParaDetails(long para_id, long para_detail_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            if (para_id == 0 && para_detail_id == 0)
                return db.Para_Details.ToList();
            else if (para_id == 0 && para_detail_id != 0)
            {
                return new List<Para_Detail> { db.Para_Details.SingleOrDefault(x => x.id == para_detail_id) };
            }
            else if (para_id != 0 && para_detail_id == 0)
            {
                return db.Para_Details.Where(x => x.para_id == para_id).ToList();
            }
            else if (para_id != 0 && para_detail_id != 0)
            {
                return new List<Para_Detail> { db.Para_Details.SingleOrDefault(x => x.para_id == para_id && x.id == para_detail_id) };
            }
            else
            {
                return new List<Para_Detail>();
            }
        }
        public List<QuranTextContainer> GetQuranTexts(long para_id, long sura_id)
        {
            QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
            List<QuranTextContainer> data = new List<QuranTextContainer>();
            if (para_id == 0 && sura_id != 0)
            {
                data = (from x in db.Quran_Texts
                        join y in db.Languages on x.lang_id equals y.id
                        join z in db.Text_Types on x.text_type_id equals z.id
                        where x.sura_id == sura_id
                        select new QuranTextContainer { Language = y, QuranText = x, TextType = z }).ToList();
            }
            else if (para_id != 0 && sura_id == 0)
            {
                data = (from x in db.Quran_Texts
                        join y in db.Languages on x.lang_id equals y.id
                        join z in db.Text_Types on x.text_type_id equals z.id
                        where x.para_id == para_id
                        select new QuranTextContainer { Language = y, QuranText = x, TextType = z }).ToList();
            }
            return data;
        }


        public string UpdateQuranText(Quran_Text text)
        {
            try
            {
                QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
                var quranText = db.Quran_Texts.SingleOrDefault(x => x.id == text.id);
                if (quranText == null)
                {
                    text.create_time = DateTime.UtcNow;
                    db.Quran_Texts.InsertOnSubmit(text);
                }
                else
                {
                    quranText.text = text.text;
                    quranText.update_time = DateTime.UtcNow;
                }
                db.SubmitChanges();
                return "True";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        public List<Section> GetSections()
        {
            try
            {
                QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
                List<Section> quranText = db.Sections.ToList();
                return quranText;
            }
            catch (Exception ex)
            {
                return new List<Section>();
            }
        }

        public List<SearchQuranResultDto> SearchQuranText(string searchText, int langId)
        {
            try
            {
                QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext();
                ISingleResult<SearchQuranResultDto> res = db.SearchInQuran(searchText, langId);
                
                return res.ToList();
            }
            catch
            {
                return new List<SearchQuranResultDto>();
            }
        }
    }
}