﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DotNetOpenAuth.AspNet;
using Microsoft.Web.WebPages.OAuth;
using WebMatrix.WebData;
using QuralTafseerTamil.Filters;
using QuralTafseerTamil.Models;
using System.Net.Mail;
using QuralTafseerTamil.Common;
using System.Configuration;
using System.Data.SqlClient;

namespace QuralTafseerTamil.Controllers
{
    [Authorize]
    [InitializeSimpleMembership]
    //[Authorize(Roles = "Admin")]
    public class AccountController : Controller
    {
        //
        // GET: /Account/Login

        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model, string returnUrl)
        {
            if (ModelState.IsValid && WebSecurity.Login(model.Email, model.Password, persistCookie: model.RememberMe))
            {
                //return RedirectToLocal(returnUrl);
                if (Roles.IsUserInRole(model.Email, "Admins"))
                {
                    return RedirectToAction("Manage");
                }
                else
                {
                    return RedirectToAction("Index", "QuranTafseer");
                }
            }

            // If we got this far, something failed, redisplay form
            ModelState.AddModelError("", "The user name or password provided is incorrect.");
            return View(model);
        }

        //
        // POST: /Account/LogOff

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            WebSecurity.Logout();

            return RedirectToAction("Index", "Home");
        }

        //
        // GET: /Account/Register

        [AllowAnonymous]
        public ActionResult Register()
        {
            return View();
        }

        //
        // POST: /Account/Register

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                // Attempt to register the user
                try
                {
                    WebSecurity.CreateUserAndAccount(model.Email, model.Password);
                    Roles.AddUserToRole(model.Email, "Users");
                    WebSecurity.Login(model.Email, model.Password);
                    return RedirectToAction("Index", "Home");
                }
                catch (MembershipCreateUserException e)
                {
                    ModelState.AddModelError("", ErrorCodeToString(e.StatusCode));
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // POST: /Account/Disassociate

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Disassociate(string provider, string providerUserId)
        {
            string ownerAccount = OAuthWebSecurity.GetUserName(provider, providerUserId);
            ManageMessageId? message = null;

            // Only disassociate the account if the currently logged in user is the owner
            if (ownerAccount == User.Identity.Name)
            {
                // Use a transaction to prevent the user from deleting their last login credential
                using (var scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.Serializable }))
                {
                    bool hasLocalAccount = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
                    if (hasLocalAccount || OAuthWebSecurity.GetAccountsFromUserName(User.Identity.Name).Count > 1)
                    {
                        OAuthWebSecurity.DeleteAccount(provider, providerUserId);
                        scope.Complete();
                        message = ManageMessageId.RemoveLoginSuccess;
                    }
                }
            }

            return RedirectToAction("Manage", new { Message = message });
        }

        //
        // GET: /Account/Manage

        public ActionResult Manage(string message)
        {
            //ViewBag.StatusMessage =
            //    message == ManageMessageId.ChangePasswordSuccess ? "Your password has been changed."
            //    : message == ManageMessageId.SetPasswordSuccess ? "Your password has been set."
            //    : message == ManageMessageId.RemoveLoginSuccess ? "The external login was removed."
            //    : "";
            ViewBag.StatusMessage = message; // string.IsNullOrEmpty(message) == false ? "Your password has been changed." : "";

            ViewBag.HasLocalPassword = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            ViewBag.ReturnUrl = Url.Action("Manage");

            return View();
        }

        //
        // POST: /Account/Manage

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Manage(LocalPasswordModel model)
        {
            bool hasLocalAccount = OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            ViewBag.HasLocalPassword = hasLocalAccount;
            ViewBag.ReturnUrl = Url.Action("Manage");
            if (hasLocalAccount)
            {
                if (ModelState.IsValid)
                {
                    // ChangePassword will throw an exception rather than return false in certain failure scenarios.
                    bool changePasswordSucceeded;
                    try
                    {
                        changePasswordSucceeded = WebSecurity.ChangePassword(User.Identity.Name, model.OldPassword, model.NewPassword);
                    }
                    catch (Exception)
                    {
                        changePasswordSucceeded = false;
                    }

                    if (changePasswordSucceeded)
                    {
                        return RedirectToAction("Manage", new { Message = ManageMessageId.ChangePasswordSuccess });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");
                    }
                }
            }
            else
            {
                // User does not have a local password so remove any validation errors caused by a missing
                // OldPassword field
                ModelState state = ModelState["OldPassword"];
                if (state != null)
                {
                    state.Errors.Clear();
                }

                if (ModelState.IsValid)
                {
                    try
                    {
                        WebSecurity.CreateAccount(User.Identity.Name, model.NewPassword);
                        return RedirectToAction("Manage", new { Message = ManageMessageId.SetPasswordSuccess });
                    }
                    catch (Exception e)
                    {
                        ModelState.AddModelError("", e);
                    }
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // POST: /Account/ExternalLogin

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLogin(string provider, string returnUrl)
        {
            return new ExternalLoginResult(provider, Url.Action("ExternalLoginCallback", new { ReturnUrl = returnUrl }));
        }

        //
        // GET: /Account/ExternalLoginCallback

        [AllowAnonymous]
        public ActionResult ExternalLoginCallback(string returnUrl)
        {
            AuthenticationResult result = OAuthWebSecurity.VerifyAuthentication(Url.Action("ExternalLoginCallback", new { ReturnUrl = returnUrl }));
            if (!result.IsSuccessful)
            {
                return RedirectToAction("ExternalLoginFailure");
            }

            if (OAuthWebSecurity.Login(result.Provider, result.ProviderUserId, createPersistentCookie: false))
            {
                return RedirectToLocal(returnUrl);
            }

            if (User.Identity.IsAuthenticated)
            {
                // If the current user is logged in add the new account
                OAuthWebSecurity.CreateOrUpdateAccount(result.Provider, result.ProviderUserId, User.Identity.Name);
                return RedirectToLocal(returnUrl);
            }
            else
            {
                // User is new, ask for their desired membership name
                string loginData = OAuthWebSecurity.SerializeProviderUserId(result.Provider, result.ProviderUserId);
                ViewBag.ProviderDisplayName = OAuthWebSecurity.GetOAuthClientData(result.Provider).DisplayName;
                ViewBag.ReturnUrl = returnUrl;
                return View("ExternalLoginConfirmation", new RegisterExternalLoginModel { Email = result.UserName, ExternalLoginData = loginData });
            }
        }

        //
        // POST: /Account/ExternalLoginConfirmation

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ExternalLoginConfirmation(RegisterExternalLoginModel model, string returnUrl)
        {
            string provider = null;
            string providerUserId = null;

            if (User.Identity.IsAuthenticated || !OAuthWebSecurity.TryDeserializeProviderUserId(model.ExternalLoginData, out provider, out providerUserId))
            {
                return RedirectToAction("Manage");
            }

            if (ModelState.IsValid)
            {
                // Insert a new user into the database
                using (UsersContext db = new UsersContext())
                {
                    UserProfile user = db.UserProfiles.FirstOrDefault(u => u.Email.ToLower() == model.Email.ToLower());
                    // Check if user already exists
                    if (user == null)
                    {
                        // Insert name into the profile table
                        db.UserProfiles.Add(new UserProfile { Email = model.Email });
                        db.SaveChanges();

                        OAuthWebSecurity.CreateOrUpdateAccount(provider, providerUserId, model.Email);
                        OAuthWebSecurity.Login(provider, providerUserId, createPersistentCookie: false);

                        return RedirectToLocal(returnUrl);
                    }
                    else
                    {
                        ModelState.AddModelError("UserName", "User name already exists. Please enter a different user name.");
                    }
                }
            }

            ViewBag.ProviderDisplayName = OAuthWebSecurity.GetOAuthClientData(provider).DisplayName;
            ViewBag.ReturnUrl = returnUrl;
            return View(model);
        }

        //
        // GET: /Account/ExternalLoginFailure

        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        [AllowAnonymous]
        [ChildActionOnly]
        public ActionResult ExternalLoginsList(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return PartialView("_ExternalLoginsListPartial", OAuthWebSecurity.RegisteredClientData);
        }

        [ChildActionOnly]
        public ActionResult RemoveExternalLogins()
        {
            ICollection<OAuthAccount> accounts = OAuthWebSecurity.GetAccountsFromUserName(User.Identity.Name);
            List<ExternalLogin> externalLogins = new List<ExternalLogin>();
            foreach (OAuthAccount account in accounts)
            {
                AuthenticationClientData clientData = OAuthWebSecurity.GetOAuthClientData(account.Provider);

                externalLogins.Add(new ExternalLogin
                {
                    Provider = account.Provider,
                    ProviderDisplayName = clientData.DisplayName,
                    ProviderUserId = account.ProviderUserId,
                });
            }

            ViewBag.ShowRemoveButton = externalLogins.Count > 1 || OAuthWebSecurity.HasLocalAccount(WebSecurity.GetUserId(User.Identity.Name));
            return PartialView("_RemoveExternalLoginsPartial", externalLogins);
        }

        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //
        // POST: /Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ForgotPassword(ForgotPassword model)
        {
            if (ModelState.IsValid)
            {
                int user = WebSecurity.GetUserId(model.Email);
                if (user == -1)
                {
                    ModelState.AddModelError("", "The user either does not exist or is not confirmed.");
                    return View();
                }

                // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                // Send an email with this link
                string code = WebSecurity.GeneratePasswordResetToken(model.Email);
                var callbackUrl = Url.Action("ResetPassword", "Account", new { userId = user, code = code }, protocol: Request.Url.Scheme);

                MailMessage message = new MailMessage();
                message.From = new MailAddress(ConfigurationManager.AppSettings["AdminEmail"].ToString());
                message.To.Add(new MailAddress(model.Email));

                message.Subject = "Reset Password";
                message.Body = @"Please reset your password by clicking <a href=\" + callbackUrl + "\">here</a>";
                message.IsBodyHtml = true;

                SendEmail.Send(message);

                return RedirectToAction("ForgotPasswordConfirmation", "Account");
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ForgotPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        //
        // GET: /Account/ResetPassword
        [AllowAnonymous]
        public ActionResult ResetPassword(string code)
        {
            if (code == null)
            {
                return View("Error");
            }
            return View();
        }

        //
        // POST: /Account/ResetPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult ResetPassword(ResetPassword model)
        {
            if (ModelState.IsValid)
            {
                var user = Membership.GetUser(model.Email);
                if (user == null)
                {
                    ModelState.AddModelError("", "No user found.");
                    return View();
                }
                bool result = WebSecurity.ResetPassword(model.Code, model.Password);
                //IdentityResult result = await UserManager.ResetPasswordAsync(user.Id, model.Code, model.Password);
                if (result)
                {
                    return RedirectToAction("ResetPasswordConfirmation", "Account");
                }
                else
                {
                    ModelState.AddModelError("", "Unable to reset password!");
                    return View();
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(LocalPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                // ChangePassword will throw an exception rather than return false in certain failure scenarios.
                bool changePasswordSucceeded;
                try
                {
                    changePasswordSucceeded = WebSecurity.ChangePassword(User.Identity.Name, model.OldPassword, model.NewPassword);
                }
                catch (Exception)
                {
                    changePasswordSucceeded = false;
                }

                if (changePasswordSucceeded)
                {
                    ViewBag.StatusMessage = "Your password has been changed";
                }
                else
                {
                    ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");
                }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/ForgotPassword
        [AllowAnonymous]
        public ActionResult UpdateCMSPage(CMSPageCode pageId)
        {
            ViewBag.Title = CMSPageCodeToString((int)pageId);

            CMSPage page = new CMSPage();
            using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
            {
                page = db.CMSPages.Where(r => r.Id == (int)pageId).FirstOrDefault();
            }
            return View(page);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult UpdateCMSPage(CMSPage model)
        {
            if (ModelState.IsValid)
            {
                // ChangePassword will throw an exception rather than return false in certain failure scenarios.
                bool resutl;
                try
                {
                    CMSPage page = new CMSPage();
                    ViewBag.Title = CMSPageCodeToString(model.Id);

                    using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
                    {
                        page = db.CMSPages.Where(r => r.Id == model.Id).FirstOrDefault();

                        if (page == null)
                        {
                            page.Title = model.Title;
                            page.Body = model.Title;

                            db.CMSPages.InsertOnSubmit(page);
                            db.SubmitChanges();
                        }
                        else
                        {
                            page.Body = model.Body;
                            db.SubmitChanges();
                        }
                    }
                    resutl = true;
                }
                catch (Exception)
                {
                    resutl = false;
                }

                if (resutl)
                {
                    ViewBag.StatusMessage = "Page has been updated";
                }
                else
                {
                    ModelState.AddModelError("", "System is unable to update the current page");
                }
            }

            // If we got this far, something failed, redisplay form
            return RedirectToAction("Manage", new { message = ViewBag.Title + " page has been updated!" });
        }


        public ActionResult UsersListing()
        {

            return PartialView("_UsersListingPartial", GetUsers());
        }

        [HttpGet]
        public ActionResult UpdateProfile()
        {
            UserProfile user = new UserProfile();
            using (UsersContext db = new UsersContext())
            {
                user = db.UserProfiles.Where(u => u.Email == User.Identity.Name).FirstOrDefault();
            }
            return PartialView("_UpdateProfilePartial", user);
        }

        [HttpPost]
        public ActionResult UpdateProfile(UserProfile model)
        {
            UserProfile user = new UserProfile();
            using (UsersContext db = new UsersContext())
            {
                user = db.UserProfiles.Where(u => u.Email == User.Identity.Name).FirstOrDefault();
                //user = model;
                user.FirstName = model.FirstName;
                user.LastName = model.LastName;
                user.MobileNo = model.MobileNo;
                user.Gender = model.Gender;
                user.ColorCode = model.ColorCode;
                user.FontSize = model.FontSize;

                db.SaveChanges();
            }
            return RedirectToAction("Manage", new { message = "Profile has been updated!" });
        }

        public JsonResult UserStatus(string userId, bool status)
        {
            bool result = false;
            string message = string.Empty;
            List<SqlParameter> param = new List<SqlParameter>() { 
                new SqlParameter("@UserID", userId),
                new SqlParameter("@Activate", status)
            };

            SqlParameter[] paramArray = param.ToArray();
            try
            {
                using (UsersContext db = new UsersContext())
                {
                    db.Database.ExecuteSqlCommand("UPDATE webpages_Membership SET IsConfirmed = @Activate WHERE UserId = @UserID", paramArray);
                }
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                message = ex.ToString();
            }

            if (result)
                return Json(new { status = "0", message = (status ? "Enable" : "Disable"), id = userId });
            else
                return Json(new { status = "1", message = message, id = userId });
        }

        public JsonResult UserNotifications()
        {
            string msg = string.Empty;
            using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
            {
                msg = db.CMSPages.Where(r => r.Id == (int)CMSPageCode.UserNotification).FirstOrDefault().Body.ToString();
            }
            return Json(new { status = "0", data = msg }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveTextSize(string textSize)
        {
            if (!User.Identity.IsAuthenticated)
                return Json(new { status = "1", data = "User is not authenticated" }, JsonRequestBehavior.AllowGet);

            int userId = WebSecurity.GetUserId(User.Identity.Name);
            using (UsersContext db = new UsersContext())
            {
                var profile = db.UserProfiles.Where(r => r.UserId == userId).FirstOrDefault();
                if (profile != null)
                {
                    profile.FontSize = textSize;
                    db.SaveChanges();
                }
            }
            return Json(new { status = "0", data = "Success" }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetTextSize()
        {
            if (!User.Identity.IsAuthenticated)
                return Json(new { status = "1", data = "User is not authenticated" }, JsonRequestBehavior.AllowGet);

            string textSize = string.Empty;
            int userId = WebSecurity.GetUserId(User.Identity.Name);
            using (UsersContext db = new UsersContext())
            {
                var profile = db.UserProfiles.Where(r => r.UserId == userId).FirstOrDefault();
                textSize = profile.FontSize;
            }
            if (string.IsNullOrEmpty(textSize))
                return Json(new { status = "1", data = string.Empty }, JsonRequestBehavior.AllowGet);
            else
                return Json(new { status = "0", data = textSize }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SendNotification()
        {
            string template = GetNotificationTemplate();
            string msg = string.Empty;
            MailMessage mail = new MailMessage();
            using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
            {
                msg = db.CMSPages.Where(r => r.Id == (int)CMSPageCode.UserNotification).FirstOrDefault().Body.ToString();
            }


            foreach (UserMembership user in GetUsers())
            {
                if (Roles.IsUserInRole(user.Email, "Users"))
                {
                    mail = new MailMessage();
                    mail.From = new MailAddress(ConfigurationManager.AppSettings["AdminEmail"].ToString(), ConfigurationManager.AppSettings["AdminName"].ToString());
                    mail.To.Add(new MailAddress(user.Email, user.FirstName + " " + user.LastName));
                    mail.Subject = ConfigurationManager.AppSettings["ContactEmailSubject"].ToString();
                    mail.IsBodyHtml = true;
                    
                    try
                    {
                        mail.Body = GetNotificationBody(msg, template);
                        Common.SendEmail.Send(mail);
                    }
                    catch
                    {}
                }
            }
            return Json(new { status = "1", data = "Notification has been sent" }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveBookmark(int suraId, int verseId)
        {
            bool res = false;
            if (WebSecurity.IsAuthenticated)
            {
                using (UsersContext db = new UsersContext())
                {
                    UserProfile profile = db.UserProfiles.Where(u => u.Email.Contains(User.Identity.Name)).FirstOrDefault();
                    profile.SuraId = suraId.ToString();
                    profile.VerseId = verseId;
                    profile.BookmarkDate = DateTime.Now;
                    db.SaveChanges();
                    res = true;
                }
            }
            if (res)
                return Json(new { status = "0", data = "Success" }, JsonRequestBehavior.AllowGet);
            else
                return Json(new { status = "1", data = "Please contact system administrator" }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBookmark()
        {
            bool res = false;
            string suraId = "1";
            int verseId = 1;
            DateTime bookmarkDate = DateTime.Now;

            if (WebSecurity.IsAuthenticated)
            {
                using (UsersContext db = new UsersContext())
                {
                    UserProfile profile = db.UserProfiles.Where(u => u.Email.Contains(User.Identity.Name)).FirstOrDefault();
                    if (!string.IsNullOrEmpty(profile.SuraId) && profile.SuraId != "0")
                    {
                        suraId = profile.SuraId;
                        verseId = profile.VerseId;
                        bookmarkDate = profile.BookmarkDate;
                        res = true;
                    }
                }
            }
            if (res)
                return Json(new { status = "0", data = new { SuraId = suraId, VerseId = verseId, BookmarkDate = bookmarkDate.ToString()} }, JsonRequestBehavior.AllowGet);
            else
                return Json(new { status = "1", data = "Please contact system administrator" }, JsonRequestBehavior.AllowGet);
        }

        #region Helpers
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        private List<UserMembership> GetUsers()
        {
            List<UserMembership> res = new List<UserMembership>();
            using (UsersContext db = new UsersContext())
            {
                List<UserProfile> users = db.UserProfiles.ToList();

                foreach (UserProfile u in users)
                {
                    if (Roles.IsUserInRole(u.Email, "Users"))
                    {
                        res.Add(new UserMembership()
                        {
                            UserId = u.UserId,
                            Email = u.Email,
                            FirstName = u.FirstName,
                            LastName = u.LastName,
                            Gender = u.Gender,
                            MobileNo = u.MobileNo,
                            IsConfirmed = WebSecurity.IsConfirmed(u.Email)
                        });
                    }
                }
            }
            return res;
        }

        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
        }

        private string GetNotificationBody(string message, string template)
        {
            string body = string.Empty;
            body = template.Replace("[MessageBody]", message);
            return body;
        }
        private string GetNotificationTemplate()
        {
            return System.IO.File.ReadAllText(Server.MapPath("~/EmailTemplates/Notification.txt"));
        }

        private string CMSPageCodeToString(int pageId)
        {
            return pageId == (int)CMSPageCode.Introduction ? "Introduction"
                                  : pageId == (int)CMSPageCode.AboutUs ? "About Us"
                                  : pageId == (int)CMSPageCode.Donate ? "Donate"
                                  : pageId == (int)CMSPageCode.UserNotification ? "Users' Notifications"
                                  : "";
        }

        internal class ExternalLoginResult : ActionResult
        {
            public ExternalLoginResult(string provider, string returnUrl)
            {
                Provider = provider;
                ReturnUrl = returnUrl;
            }

            public string Provider { get; private set; }
            public string ReturnUrl { get; private set; }

            public override void ExecuteResult(ControllerContext context)
            {
                OAuthWebSecurity.RequestAuthentication(Provider, ReturnUrl);
            }
        }

        private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        {
            // See http://go.microsoft.com/fwlink/?LinkID=177550 for
            // a full list of status codes.
            switch (createStatus)
            {
                case MembershipCreateStatus.DuplicateUserName:
                    return "User name already exists. Please enter a different user name.";

                case MembershipCreateStatus.DuplicateEmail:
                    return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

                case MembershipCreateStatus.InvalidPassword:
                    return "The password provided is invalid. Please enter a valid password value.";

                case MembershipCreateStatus.InvalidEmail:
                    return "The e-mail address provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidAnswer:
                    return "The password retrieval answer provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidQuestion:
                    return "The password retrieval question provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidUserName:
                    return "The user name provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.ProviderError:
                    return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                case MembershipCreateStatus.UserRejected:
                    return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                default:
                    return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
            }
        }
        #endregion
    }
}
