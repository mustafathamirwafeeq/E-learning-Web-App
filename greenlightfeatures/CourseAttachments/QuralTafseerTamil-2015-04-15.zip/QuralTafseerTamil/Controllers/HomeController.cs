﻿using QuralTafseerTamil.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QuralTafseerTamil.Models;
using System.Net.Mail;
using System.Configuration;
using System.Text;

namespace QuralTafseerTamil.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var content = PageContent(CMSPageCode.Introduction);

            return View(content);
        }

        public ActionResult Donate()
        {
            var content = PageContent(CMSPageCode.Donate);
            return View(content);
        }
        
        public ActionResult About()
        {
            var content = PageContent(CMSPageCode.AboutUs);
            return View(content);            
        }

        [HttpGet]
        public ActionResult Contact(string status)
        {
            ViewBag.StatusMessage = status;
            return View();
        }

        [HttpPost]
        public ActionResult Contact(ContactDto model)
        {
            string msg = string.Empty;
            if (ModelState.IsValid)
            {
                MailMessage message = new MailMessage();

                message.From = new MailAddress(ConfigurationManager.AppSettings["AdminEmail"].ToString(), ConfigurationManager.AppSettings["AdminName"].ToString());
                message.To.Add(new MailAddress(model.Email, model.FirstName + " " + model.LastName));
                message.Subject = ConfigurationManager.AppSettings["ContactEmailSubject"].ToString();

                //
                string messageTemplate = GetMessageTemplate();
                string messageBody = string.Empty;
                messageBody = messageTemplate.Replace("[Name]", model.FirstName + " " + model.LastName);
                messageBody = messageBody.Replace("[Email]", model.Email);
                messageBody = messageBody.Replace("[Subject]", model.Subject);
                messageBody = messageBody.Replace("[Message]", model.Message);

                message.Body = messageBody;
                message.IsBodyHtml = true;
                //
                bool res = Common.SendEmail.Send(message);
                if (res)
                {
                    msg = "Message has been sent.";
                    
                }
                else
                {
                   msg = "Unable to send message.";
                    
                }
            }
            return RedirectToAction("Contact", new { status = msg });      
        }

        private string GetMessageTemplate()
        {
            return System.IO.File.ReadAllText(Server.MapPath("~/EmailTemplates/Contact.txt"));
        }

        private CMSPage PageContent(CMSPageCode pageId)
        {
            CMSPage page = new CMSPage();
            using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
            {
                page = db.CMSPages.Where(r => r.Id == (int)pageId).FirstOrDefault();
            }
            return page;
        }
    }
}
