﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QuralTafseerTamil;
using QuralTafseerTamil.Models;
using QuralTafseerTamil.Filters;
using WebMatrix.WebData;
using System.Net.Mail;
using System.Configuration;

namespace QuralTafseerTamil.Controllers
{
    [InitializeSimpleMembership]
    public class QuranTafseerController : Controller
    {
        //
        // GET: /QuranTafseer/

        public ActionResult Index(int? suraId, int? verseId)
        {
            long lang_id = 3;
            List<Sura> suras = Utilities.LoadSuras(0, lang_id); // Provide Lang as Arabic to load Arabic Suras

            int alignment = Utilities.LoadLanguages(lang_id).FirstOrDefault().text_align;
            bool isRight = alignment == 0 ? false : true;


            List<SelectListItem> Suras = suras.Select(x => new SelectListItem { Text = (x.Sura_Details.Count == 0 ? "NoName" : x.sequence.ToString() + ". " + x.Sura_Details.FirstOrDefault().name), Value = x.id.ToString() + ":" + x.verses.ToString() }).ToList();
            Suras.RemoveAll(x => x.Text == "NoName");
            if (Suras == null || Suras.Count == 0)
            {
                suras = Utilities.LoadSuras(0, 2);
                Suras = suras.Select(x => new SelectListItem { Text = (isRight ? (x.Sura_Details.Count == 0 ? "NoName" : x.Sura_Details.FirstOrDefault().name + " ." + x.sequence.ToString()) : (x.Sura_Details.Count == 0 ? "NoName" : x.sequence.ToString() + ". " + x.Sura_Details.FirstOrDefault().name)), Value = x.id.ToString() + ":" + x.verses.ToString() }).ToList();
                Suras.RemoveAll(x => x.Text == "NoName");
            }

            ViewBag.Suras = Suras;

            List<Text_Type> textType = Utilities.LoadTextTypes();
            List<SelectListItem> textTypes = textType.Select(x => new SelectListItem { Text = x.name, Value = x.id.ToString() }).ToList();
            textTypes.Where(x => x.Text == "Explaination/Tafseer").FirstOrDefault().Selected = true;
            ViewBag.TextTypes = textTypes;

            ViewBag.LangId = lang_id;

            ViewBag.IsRight = isRight;

            List<Section> sections = Utilities.GetSections();

            List<SelectListItem> Juz = new List<SelectListItem>();
            List<SelectListItem> Hizb = new List<SelectListItem>();
            List<SelectListItem> Manzil = new List<SelectListItem>();
            List<SelectListItem> Ruku = new List<SelectListItem>();
            List<SelectListItem> Sajda = new List<SelectListItem>();

            int ind = 1;

            Juz = sections.Where(x => x.content_type == 1).ToList().Select(x => new SelectListItem { Text = (ind++).ToString(), Value = x.sura.ToString() + ":" + x.aya.ToString() }).ToList();
            ind = 1;
            Hizb = sections.Where(x => x.content_type == 2).ToList().Select(x => new SelectListItem { Text = (ind++).ToString(), Value = x.sura.ToString() + ":" + x.aya.ToString() }).ToList();
            ind = 1;
            Manzil = sections.Where(x => x.content_type == 3).ToList().Select(x => new SelectListItem { Text = (ind++).ToString(), Value = x.sura.ToString() + ":" + x.aya.ToString() }).ToList();
            ind = 1;
            Ruku = sections.Where(x => x.content_type == 4).ToList().Select(x => new SelectListItem { Text = (ind++).ToString(), Value = x.sura.ToString() + ":" + x.aya.ToString() }).ToList();
            ind = 1;
            Sajda = sections.Where(x => x.content_type == 5).ToList().Select(x => new SelectListItem { Text = (ind++).ToString(), Value = x.sura.ToString() + ":" + x.aya.ToString() }).ToList();

            ViewBag.Juzs = Juz;
            ViewBag.Hizbs = Hizb;
            ViewBag.Manzils = Manzil;
            ViewBag.Rukus = Ruku;
            ViewBag.Sajdas = Sajda;
            int userSuraId = 1; // GetUserSuraId()
            ViewBag.UserSuraId = userSuraId.ToString() + ":" + suras.Where(r => r.id == userSuraId).FirstOrDefault().verses.ToString();

            // referred information 
            ViewBag.RefferedSuraId = suraId.HasValue ? suraId.Value : 0;
            ViewBag.RefferedVerseId = verseId.HasValue ? verseId.Value : 0;

            return View();
        }

        public ActionResult LoadSuraContents(long sura, int verses, string hide)
        {
            long para = 0;
            List<HideLanguageText> exceptions = hide.Split(':').ToList().Select(x => new HideLanguageText { lang_id = long.Parse(x.Split(',')[0]), type_id = long.Parse(x.Split(',')[1]) }).ToList();

            List<QuranTextContainer> model = Utilities.LoadQuranText(para, sura);
            List<Language> langs = Utilities.LoadLanguages(0);
            List<Text_Type> types = Utilities.LoadTextTypes(0);

            for (int i = 1; i <= verses; i++)
            {
                foreach (Language lng in langs)
                {
                    foreach (Text_Type t in types)
                    {
                        var data = model.Where(x => x.QuranText.text_type_id == t.id && x.QuranText.lang_id == lng.id && x.QuranText.verse_number == i).FirstOrDefault();
                        if (data == null)
                        {
                            HideLanguageText ex = new HideLanguageText { lang_id = lng.id, type_id = t.id };
                            if (exceptions.Contains(ex))
                            {
                                Quran_Text nData = new Quran_Text { lang_id = lng.id, verse_number = i, sura_id = sura, para_id = para, text = "", text_type_id = t.id };
                                model.Add(new QuranTextContainer { Language = lng, TextType = t, QuranText = nData });
                            }
                        }
                    }
                }
            }
            model = model.OrderBy(x => x.QuranText.verse_number).ThenBy(x => x.QuranText.text_type_id).ThenBy(x => x.QuranText.lang_id).ToList();

            if (sura != 1)
            {
                string bis = Utilities.LoadQuranText(0, 1).FirstOrDefault().QuranText.text;
                ViewBag.Bismillah = bis;
            }            
            return View(model);
        }

        public JsonResult LoadSuraContentsExtra(long sura)
        {
            Sura s = Utilities.LoadSuras(sura).FirstOrDefault();
            return Json(new { verses = s.verses, ruku = s.ruku, order = s.order, type = s.type, name = s.Sura_Details.FirstOrDefault().name }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SearchInQuran(string searchText, int langId)
        {
            if (string.IsNullOrEmpty(searchText))
                throw new Exception("search text is empty");

            string markedText = "<mark>" + searchText + "</mark>";
            List<SearchQuranResultDto> searchResult = Utilities.SearchInQuran(searchText, langId);
            foreach (var r in searchResult)
            {
                r.text = r.text.Replace(searchText, markedText);
            }
            if (Request.IsAjaxRequest())
                return PartialView("_SearchQuranResultPartial", searchResult);
            else
                return View();

            //return Json(new { status = "0" , data= searchResult  }, JsonRequestBehavior.AllowGet);
        }

        //[HttpGet]
        //public ActionResult UpdateTafseer(int suraId, int versesId, int langId)
        //{
        //    Quran_Text res = new Quran_Text();
        //    using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
        //    {
        //        res = (from d in db.Quran_Texts
        //               where d.sura_id == (int)suraId && d.verse_number == (int)versesId && d.lang_id == langId
        //               select d).FirstOrDefault();
        //    }

        //    return View(res);
        //}

        //[HttpPost]
        //public ActionResult UpdateTafseer(Quran_Text model)
        //{
        //    return View();
        //}

        [HttpPost]
        public ActionResult SaveTafseer(int paraId, int suraId, int versesId, int langId, int textTypeId, string translatedText)
        {
            bool result = false;
            Quran_Text res = new Quran_Text();
            using (QuranPortalDatabaseDataContext db = new QuranPortalDatabaseDataContext())
            {
                res = (from d in db.Quran_Texts
                       where d.sura_id == (int)suraId && d.verse_number == (int)versesId && d.lang_id == langId && d.text_type_id == (int)textTypeId
                       select d).FirstOrDefault();
                if (res == null)
                {
                    Quran_Text obj = new Quran_Text();
                    obj.lang_id = (int)langId;
                    obj.para_id = (int)paraId;
                    obj.sura_id = (int)suraId;
                    obj.text_type_id = textTypeId;
                    obj.verse_number = (int)versesId;

                    obj.text = translatedText;

                    obj.update_time = DateTime.Now;
                    obj.create_time = DateTime.Now;

                    db.Quran_Texts.InsertOnSubmit(obj);

                }
                else
                {
                    res.text = translatedText;
                    res.update_time = DateTime.Now;
                }

                db.SubmitChanges();
                result = true;

            }

            if (result)
                return Json(new { status = "0", message = "Success" });
            else
                return Json(new { status = "1", message = "Error" });
        }

        [HttpPost]
        public ActionResult SendTafseer(string FromName, string FromEmail, string ToName, string ToEmail, int referredSuraId, int referredVerseId)
        {
            string result = string.Empty;
            bool res = false;
            try
            {
                MailMessage message = new MailMessage();

                message.From = new MailAddress(FromEmail, FromName);
                message.To.Add(new MailAddress(ToEmail, ToName));
                message.Subject = ConfigurationManager.AppSettings["ContactEmailSubject"].ToString();

                //
                string messageTemplate = GetMessageTemplate();
                string messageBody = string.Empty;
                messageBody = messageTemplate.Replace("[From]", FromName);
                messageBody = messageBody.Replace("[To]", ToName);
                messageBody = messageBody.Replace("[Link]", "<a href='" + GetURL(referredSuraId, referredVerseId) + "'>click here</a>");

                message.Body = messageBody;
                message.IsBodyHtml = true;
                //
                res = Common.SendEmail.Send(message);
            }
            catch(Exception ex)
            {
                result = ex.ToString();
            }

            if (Request.IsAjaxRequest())
            {
                if (res)
                {
                    result = "Message has been sent.";
                    return Json(new { status = "0", message = result });
                }
                else
                {
                    return Json(new { status = "1", message = result });
                }
            }
            else
                return View();

        }
        
        private string GetURL(int suraId, int verseId)
        {
            return "http://" + Request.Url.Host + "/QuranTafseer?suraId=" + suraId.ToString() + "&verseId=" + verseId.ToString();
        }

        public ActionResult SendToFriend()
        {
            return PartialView("_SendToFriendPartial");
        }

        private string GetMessageTemplate()
        {
            return System.IO.File.ReadAllText(Server.MapPath("~/EmailTemplates/SendVerse.txt"));
        }

        //private void SaveUserSuraId(int suraId, int verseId)
        //{
        //    if (WebSecurity.IsAuthenticated)
        //    {
        //        using (UsersContext db = new UsersContext())
        //        {
        //            UserProfile profile = db.UserProfiles.Where(u => u.Email.Contains(User.Identity.Name)).FirstOrDefault();
        //            profile.SuraId = suraId.ToString();
        //            profile.VerseId = verseId;
        //            profile.BookmarkDate = DateTime.Now;
        //            db.SaveChanges();
        //        }
        //    }
        //}

        //private Int32 GetUserSuraId()
        //{
        //    string suraId = "1";
        //    if (WebSecurity.IsAuthenticated)
        //    {
        //        using (UsersContext db = new UsersContext())
        //        {
        //            UserProfile profile = db.UserProfiles.Where(u => u.Email.Contains(User.Identity.Name)).FirstOrDefault();
        //            if (!string.IsNullOrEmpty(profile.SuraId) && profile.SuraId != "0")
        //                suraId = profile.SuraId;
        //        }
        //    }
        //    return Convert.ToInt32(suraId);
        //}
    }
}
