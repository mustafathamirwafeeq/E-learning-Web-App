﻿using QuralTafseerTamil.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuralTafseerTamil
{
    public static class Utilities
    {
        static IUtilities dbUtilities = new dbUtilities();

        public static List<Language> LoadLanguages(long lang_id = 0)
        {
            return dbUtilities.GetLanguages(lang_id);
        }
        public static List<Text_Type> LoadTextTypes(long text_type_id = 0)
        {
            return dbUtilities.GetTextTypes(text_type_id);
        }
        public static List<Sura> LoadSuras(long sura_id= 0,long lang_id = 1)
        {
            List<Sura> tempSuras = dbUtilities.GetSuras(sura_id);
            int ind = 0;
            foreach (var item in tempSuras)
            {
                var val = dbUtilities.GetSuraDetails(item.id, 0).Where(x => x.lang_id == lang_id).FirstOrDefault();
                if (val == null)
                    tempSuras[ind].Sura_Details = new System.Data.Linq.EntitySet<Sura_Detail>();
                else
                tempSuras[ind].Sura_Details = new System.Data.Linq.EntitySet<Sura_Detail>{ val };
                ind++;
            }

            return tempSuras;
        }
        public static List<QuranTextContainer> LoadQuranText(long para,long sura)
        {
            return dbUtilities.GetQuranTexts(para, sura);
        }
        public static string UpdateQuranText(Quran_Text text)
        {
            return dbUtilities.UpdateQuranText(text);
        }
        public static List<Section> GetSections()
        {
            return dbUtilities.GetSections();
        }

        public static List<SearchQuranResultDto> SearchInQuran(string searchText, int langId)
        {
            return dbUtilities.SearchQuranText(searchText, langId);
        }
    }

    public class QuranTextContainer
    {
        public Quran_Text QuranText { get; set; }
        public Language Language { get; set; }
        public Text_Type TextType { get; set;}
    }
    
    public class HideLanguageText
    {
        public long lang_id { get; set; }
        public long type_id { get; set; }
    }
}