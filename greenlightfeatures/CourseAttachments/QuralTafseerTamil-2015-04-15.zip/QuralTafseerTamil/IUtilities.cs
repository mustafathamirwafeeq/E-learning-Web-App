﻿using QuralTafseerTamil.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuralTafseerTamil
{
    interface IUtilities
    {
        List<Language> GetLanguages(long lang_id);
        List<Text_Type> GetTextTypes(long text_type_id);
        List<Sura> GetSuras(long sura_id);
        List<Sura_Detail> GetSuraDetails(long sura_id, long sura_detail_id);
        List<Para> GetParas(long para_id);
        List<Para_Detail> GetParaDetails(long para_id, long para_detail_id);
        List<QuranTextContainer> GetQuranTexts(long para_id, long sura_id);
        string UpdateQuranText(Quran_Text text);
        List<Section> GetSections();
        List<SearchQuranResultDto> SearchQuranText(string searchText, int langId);
    }
}
