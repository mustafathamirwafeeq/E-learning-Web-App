﻿using System;
using System.Net.Mail;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace QuralTafseerTamil.Common
{
    public enum CMSPageCode
    {
        Introduction = 1,
        AboutUs = 2,
        Donate = 3,
        Contact = 4,
        UserNotification = 5
    }

    public static class SendEmail
    {
        public static bool Send(MailMessage mm)
        {
            SmtpClient smtp = new SmtpClient();
            try
            {
                smtp.Send(mm);
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                mm.Dispose();
                smtp = null;
            }

        }
    }

}