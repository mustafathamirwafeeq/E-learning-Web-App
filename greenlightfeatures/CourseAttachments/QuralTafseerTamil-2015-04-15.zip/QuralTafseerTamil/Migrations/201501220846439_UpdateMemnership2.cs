namespace QuralTafseerTamil.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    using System.Web.Security;
    using WebMatrix.WebData;
    using System.Linq;

    public partial class UpdateMemnership2 : DbMigration
    {
        public override void Up()
        {
            
            AddColumn("dbo.UserProfile", "FirstName", c => c.String());
            AddColumn("dbo.UserProfile", "LastName", c => c.String());
            AddColumn("dbo.UserProfile", "Gender", c => c.String());
            AddColumn("dbo.UserProfile", "MobileNo", c => c.String());
            AddColumn("dbo.UserProfile", "ColorCode", c => c.String());
            AddColumn("dbo.UserProfile", "FontSize", c => c.String());
            AddColumn("dbo.UserProfile", "SuraId", c => c.Int());

            //if (!Roles.RoleExists("Admins"))
            //    Roles.CreateRole("Admins");
            //if (!Roles.RoleExists("Users"))
            //    Roles.CreateRole("Users");

            //if (!WebSecurity.UserExists("admin"))
            //    WebSecurity.CreateUserAndAccount(
            //        "admin@abc.com",
            //        "1234567*",
            //        new
            //        {
            //            FirstName = "Web",
            //            LastName = "Admin",
            //            Gender = "Male",
            //            MobileNo = "+92300 4218381",
            //            ColorCode = "#fff",
            //            FontSize = "12px",
            //            SuraId = "0"
            //        });

            //if (!Roles.GetRolesForUser("admin").Contains("Admins"))
            //    Roles.AddUsersToRoles(new[] { "admin" }, new[] { "Admins" });
        }
        
        public override void Down()
        {
        }
    }
}
