namespace QuralTafseerTamil.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UserVerseInfo : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.UserProfile", "VerseId", c => c.Int());
            AddColumn("dbo.UserProfile", "BookmarkDate", c => c.DateTime());
        }
        
        public override void Down()
        {
        }
    }
}
