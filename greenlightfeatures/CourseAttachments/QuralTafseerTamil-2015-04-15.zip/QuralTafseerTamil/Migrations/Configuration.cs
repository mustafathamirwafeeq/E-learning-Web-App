namespace QuralTafseerTamil.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using System.Web.Security;
    using WebMatrix.WebData;

    internal sealed class Configuration : DbMigrationsConfiguration<QuralTafseerTamil.Models.UsersContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
        }

        protected override void Seed(QuralTafseerTamil.Models.UsersContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            WebSecurity.InitializeDatabaseConnection("DefaultConnection", "UserProfile", "UserId", "Email", autoCreateTables: true);

            if (!Roles.RoleExists("Admins"))
                Roles.CreateRole("Admins");
            if (!Roles.RoleExists("Users"))
                Roles.CreateRole("Users");

            if (!WebSecurity.UserExists("admin@abc.com"))
                WebSecurity.CreateUserAndAccount(
                    "admin@abc.com",
                    "1234567*",
                    new { FirstName = "Web", LastName="Admin", Gender = "Male", MobileNo = "+92300 4218381", 
                            ColorCode = "#fff", FontSize = "12px", SuraId = "0"});

            if (!Roles.GetRolesForUser("admin@abc.com").Contains("Admins"))
                Roles.AddUsersToRoles(new[] { "admin@abc.com" }, new[] { "Admins" });

        }
    }
}
